将/hyperlpr_pip_pkg/hyperlpr/models/dnn/目录下的

mininet_ssd_v1.caffemodel
mininet_ssd_v1.prototxt
refinenet.caffemodel
refinenet.prototxt
SegmenationFree-Inception.caffemodel
SegmenationFree-Inception.prototxt


放置在该目录